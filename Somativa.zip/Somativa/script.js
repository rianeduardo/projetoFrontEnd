const luzes = document.querySelectorAll('.luz');
let indiceAtual = 0;

function mudarSemaforo() { // apagar as luzes acesas
    luzes.forEach(luz => luz.className = 'luz' );

    if (indiceAtual == 0 ) {   // acender a luz do semaforo
        document.getElementById('verde').classList.add('verde');
    } else if (indiceAtual == 1) {
        document.getElementById('amarelo').classList.add('amarelo');    
    } else if (indiceAtual == 2) {
        document.getElementById('vermelho').classList.add('vermelho');    
    }
  
    // troca de cor das luzes 
    indiceAtual = (indiceAtual + 1) % luzes.length;
    }

// mudar as cores de 2 em 2 segundos
setInterval(mudarSemaforo, 2000); //2000 milissegundos = 2 segundos

// temporizador "setInterval" foi usado para repetir 